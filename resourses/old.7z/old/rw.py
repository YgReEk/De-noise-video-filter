import sys
from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import *


class filedialogdemo(QWidget):
    def __init__(self, parent=None):
        super(filedialogdemo, self).__init__(parent)

        layout = QVBoxLayout()
        self.btn = QPushButton("QFileDialog static method demo")
        self.btn2 = QPushButton("QExit demo")
        self.btn2.clicked.connect(self.close)
        self.btn.clicked.connect(self.getfile)
        layout.addWidget(self.btn2)
        layout.addWidget(self.btn)
        #self.le = QLabel("Hello")
        #layout.addWidget(self.le)
        self.setLayout(layout)
        #self.setWindowTitle("File Dialog demo")

    def getfile(self):
        QFileDialog.getOpenFileName(self, 'Open file',
                                            'c:\\', "Image files (*.jpg *.gif)")
        #self.le.setPixmap(QPixmap(fname))

    def close(self):
        self.close()

def main():
    app = QApplication(sys.argv)
    ex = filedialogdemo()
    ex.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()
