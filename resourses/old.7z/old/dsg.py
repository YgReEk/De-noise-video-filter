from tkinter import *
from tkinter.ttk import *
import tkinter.filedialog as tkFileDialog
import cv2
import shutil
import tempfile
import LicenseForm


def Quit(ev):
    global root
    root.destroy()


def LoadFile(ev):
    lf = tkFileDialog.Open(root, filetypes=[('Images', '.png'), ('Videos', '.avi')]).show()
    if lf == '':
        return


def CheckFile(ev):
    if Video:
        if iaddr[iaddr.rfind('.'):] == '.avi':
            pass
        else:
            return
    else:
        if iaddr[iaddr.rfind('.'):] == '.png':
            pass
        else:
            return


root = Tk()
icon = PhotoImage(file=r'C:\Users\Игорь\PycharmProjects\De-noise-video-filter\resourses\icon.png')
root.tk.call('wm', 'iconphoto', root._w, icon)

MainFrame = Frame(root, height=460, width=800)
MainFrame.grid(column=0, row=0, padx=10, pady=10)

Default_fs_luminocity_label = Label(MainFrame, text='Default: 4')
Default_fs_luminocity_label.grid(column=0, row=9, sticky=(S, W), padx=6, pady=4)

FS_luminocity_label = Label(MainFrame, text='Filter luminosity strenght')
FS_luminocity_label.grid(column=2, row=9, sticky=(S, E), padx=6, pady=4)

Default_fs_color_label = Label(MainFrame, text='Default: 5')
Default_fs_color_label.grid(column=3, row=9, sticky=(S, W), padx=6, pady=4)

FS_color_label = Label(MainFrame, text='Filter color strenght')
FS_color_label.grid(column=5, row=9, sticky=(S, E), padx=6, pady=4)

Open_file_label = Label(MainFrame, text='Open file: ')
Open_file_label.grid(column=1, row=10, sticky=(S, E), padx=2, pady=6)

EMU_label = Label(MainFrame, text='Estimated memory use: ')
EMU_label.grid(column=0, row=6, sticky=(S, W), padx=6, pady=4)

EDT_label = Label(MainFrame, text='Estimated denoising time: ')
EDT_label.grid(column=3, row=6, sticky=(S, W), padx=6, pady=4)

EMU_show_text = StringVar()
EMU_show = Label(MainFrame)
EMU_show['textvariable'] = EMU_show_text
EMU_show.grid(column=2, row=6, sticky=(S, E), padx=6, pady=4)
EMU_show_text.set('')

EDT_show_text = StringVar()
EDT_show = Label(MainFrame)
EDT_show['textvariable'] = EDT_show
EDT_show.grid(column=5, row=6, sticky=(S, E), padx=6, pady=4)
EDT_show_text.set('')

colored = True
def colorchanged(colored):
    if colored:
        colored=False
    else:
        colored=True
    return colored
GrayScale = StringVar()
check = Checkbutton(MainFrame, text='GrayScale', command=colorchanged(colored), variable=colored, onvalue='metric',
                    offvalue='imperial')
check.grid(column=0, row=7, sticky=(S, W), padx=6, pady=6)

iaddr = r'C:\Users\Игорь\test.png'
taddr = tempfile.NamedTemporaryFile().name + iaddr[iaddr.rfind('.'):]
shutil.copyfile(iaddr, taddr)
Img = cv2.imread(taddr)
cv2.imwrite(taddr, cv2.resize(Img, (380, 214), 0, 0, interpolation=cv2.INTER_AREA))
OriginalPreview = PhotoImage(file=taddr)
Orig = Label(MainFrame)
Orig['image'] = OriginalPreview
Orig.grid(column=0, row=0, columnspan=3, rowspan=6, sticky=(N, S, E, W), padx=6, pady=6)

oaddr = r'C:\Users\Игорь\test-denoised.png'
tdaddr = tempfile.NamedTemporaryFile().name + iaddr[iaddr.rfind('.'):]
shutil.copyfile(oaddr, tdaddr)
Img = cv2.imread(tdaddr)
cv2.imwrite(tdaddr, cv2.resize(Img, (380, 214), 0, 0, interpolation=cv2.INTER_AREA))
DemoisedPreview = PhotoImage(file=tdaddr)
Den = Label(MainFrame)
Den['image'] = DemoisedPreview
Den.grid(column=3, row=0, columnspan=3, rowspan=6, sticky=(N, S, E, W), padx=6, pady=6)

LFS = Scale(MainFrame, orient=HORIZONTAL, from_=1, to=30)
LFS.set(4)
LFS.grid(column=0, row=8, columnspan=3, sticky=(N, S, E, W), padx=6, pady=2)

CFS = Scale(MainFrame, orient=HORIZONTAL, from_=1, to=30)
CFS.set(5)
CFS.grid(column=3, row=8, columnspan=3, sticky=(N, S, E, W), padx=6, pady=2)

FileAddr = StringVar()
InputAdress = Entry(MainFrame, textvariable=FileAddr)
InputAdress.grid(column=2, row=10, columnspan=3, sticky=(N, S, E, W), padx=6, pady=6)

FileButton = Button(MainFrame, text='Browse')
FileButton.grid(column=0, row=10, sticky=(S, W), padx=6, pady=6)
FileButton.bind("<Button-1>", LoadFile)

DenoiseButton = Button(MainFrame, text='Denoise it!')
DenoiseButton.grid(column=5, row=10, sticky=(S, E), padx=6, pady=6)

ProgressDenoising = Progressbar(MainFrame, orient=HORIZONTAL, mode='determinate')
ProgressDenoising.grid(column=1, row=7, columnspan=4, sticky=(N, S, E, W), padx=6, pady=6)

# Determinate Progess
# In determinate mode, you're able to provide more-or-less accurate feedback to the user about how far an operation has progressed. To do this, you need to first of all tell the progressbar how many "steps" the operation will take, and then as you go along, tell the progressbar how far along the operation is.
# You can provide the total number of steps to the progressbar using the "maximum" configuration option; this is a floating point number that defaults to 100 (i.e. each step is 1%). To tell the progressbar how far along you are in the operation, you will repeatedly change the "value" configuration option. So this would start at 0, and then count upwards to the maximum value you have set. There are two slight variations on this. First, you can just store the current value for the progressbar in a variable linked to it by the progressbar's "variable" configuration option; that way, when you change the variable, the progressbar will update. The other alternative is to call the progressbar's "step ?amount?" method to increment the value by the given "amount" (defaults to 1.0).
# Indeterminate Progress
# Indeterminate mode is for when you're not able to easily know (or estimate) how far along in a long running task you actually are, but still want to provide feedback to the user that the operation is still running (or that your program hasn't crashed). Rather than providing specific values to indicate progress along the way, at the start of the operation you'll just call the progressbar's "start" method, and at the end of the operation, you'll call its "stop" method. The progressbar will take care of the rest.

def setresolution():
    pass


Resolution = Combobox(MainFrame,
                      values=['Same as source', 'VGA (640*480)', 'SVGA (800*600)', 'qHD (960*540)', 'HD (1280*720)',
                              'XGA+ (1152*864)', 'HD+ (1600*900)', 'UXGA (1600*1200)', 'FullHD (1920*1080)'])
Resolution.set('Same as source')
Resolution.grid(column=5, row=7, sticky=(S, E), padx=6, pady=6)
# Resolution.place(x=570, y=290, width=111, height=22)
Resolution.bind('<<ComboboxSelected>>', setresolution)

menubar = Menu(root)

menu_file = Menu(menubar, tearoff=0)
menu_file.add_command(label='Open...', command=LoadFile)
menu_file.add_separator()
menu_file.add_command(label='Exit', command=root.quit)
menubar.add_cascade(menu=menu_file, label='File')

menu_edit = Menu(menubar, tearoff=0)
menu_edit.add_command(label='Colored')
menu_edit.add_command(label='Set filter luminosity strenght')
menu_edit.add_command(label='Filter color strenght')

menu_res = Menu(menu_edit, tearoff=0)
menu_res.add_command(label='Same as source')
menu_res.add_command(label='VGA (640*480)')
menu_res.add_command(label='SVGA (800*600)')
menu_res.add_command(label='qHD (960*540)')
menu_res.add_command(label='HD (1280*720)')
menu_res.add_command(label='XGA+ (1152*864)')
menu_res.add_command(label='HD+ (1600*900)')
menu_res.add_command(label='UXGA (1600*1200)')
menu_res.add_command(label='FullHD (1920*1080)')

menubar.add_cascade(menu=menu_edit, label='Edit')
menu_edit.add_cascade(menu=menu_res, label='Resolution')

menu_about = Menu(menubar, tearoff=0)
menu_about.add_command(label='License', command=LicenseForm.init)
menu_about.add_command(label='Author')
menu_about.add_command(label='About')
menu_about.add_command(label='HowTo:')
menubar.add_cascade(menu=menu_about, label='About')


root.config(menu=menubar)
root.mainloop()
